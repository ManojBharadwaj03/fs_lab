"""
main.py
-------
End-to-end CLI pipeline for the Real Estate Pricing & Geographic
Micro-Market Clustering case study.

Usage
-----
    python main.py --clusters 7
    python main.py --clusters 7 --sample-elbow           # also run elbow-method scan (slower)
    python main.py --predict                             # run a demo single-property prediction

This script:
  1. Loads and cleans the data
  2. Engineers features
  3. Runs K-Means to discover micro-market clusters (with auto-naming)
  4. Trains a global baseline model + champion/challenger models per cluster
  5. Compares global vs. per-cluster performance
  6. Computes the Investment Opportunity Score per cluster
  7. Flags over/undervalued properties
  8. Computes SHAP feature importance per cluster
  9. Saves all figures, the interactive valuation map, and all trained models
"""

import argparse
import os
import sys
import joblib
import warnings
warnings.filterwarnings("ignore")

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from data_loader import load_housing_data
from preprocessing import build_feature_matrix
from clustering import find_optimal_k, fit_kmeans, assign_clusters
from modeling import make_global_split, train_global_baseline, train_cluster_models, compare_global_vs_cluster
from valuation_score import compute_investment_score, flag_over_under_valued, top_deals
from explainability import compute_cluster_shap_importance, top_driver_per_cluster, plot_cluster_driver_heatmap
from geo_visuals import build_cluster_valuation_map
from visualize import plot_elbow, plot_cluster_map, plot_rmse_comparison, plot_investment_scores
from predict import predict_price


def run_pipeline(n_clusters: int, data_path: str, run_elbow_scan: bool, run_shap: bool,
                  models_dir: str = "models"):
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs("reports/figures", exist_ok=True)

    print("\n" + "=" * 70)
    print(" STEP 1-3: LOAD, CLEAN & ENGINEER FEATURES")
    print("=" * 70)
    raw = load_housing_data(data_path)
    processed, scaler, scaled_cluster_features = build_feature_matrix(raw)

    print("\n" + "=" * 70)
    print(" STEP 4: GEOGRAPHIC MICRO-MARKET CLUSTERING")
    print("=" * 70)
    if run_elbow_scan:
        elbow_df = find_optimal_k(scaled_cluster_features)
        plot_elbow(elbow_df, chosen_k=n_clusters)

    km = fit_kmeans(scaled_cluster_features, n_clusters=n_clusters)
    processed, cluster_names = assign_clusters(processed, km, scaled_cluster_features)
    plot_cluster_map(processed)

    print("\n" + "=" * 70)
    print(" STEP 5: MODEL TRAINING (GLOBAL BASELINES + PER-CLUSTER CHAMPIONS)")
    print("=" * 70)
    train_idx, test_idx = make_global_split(processed)

    print("-- Naive global baseline (single Linear Regression, no clustering) --")
    global_linear_model, global_linear_metrics, _ = train_global_baseline(
        processed, train_idx, test_idx, algorithm="linear_regression"
    )

    print("-- Strong global baseline (single XGBoost, no clustering) --")
    global_model, global_metrics, features = train_global_baseline(
        processed, train_idx, test_idx, algorithm="xgboost"
    )

    print("-- Per-cluster champion/challenger models --")
    cluster_models, cluster_metrics, candidate_metrics, _ = train_cluster_models(processed, train_idx, test_idx)

    print("\n" + "=" * 70)
    print(" STEP 6: GLOBAL vs. PER-CLUSTER COMPARISON")
    print("=" * 70)
    comparison = compare_global_vs_cluster(
        processed, global_model, cluster_models, features, test_idx,
        global_linear_model=global_linear_model,
    )
    print(comparison.to_string(index=False))
    plot_rmse_comparison(comparison)

    overall_improvement = (
        (comparison["global_rmse"].mean() - comparison["cluster_rmse"].mean())
        / comparison["global_rmse"].mean() * 100
    )
    overall_improvement_vs_linear = (
        (comparison["global_linear_rmse"].mean() - comparison["cluster_rmse"].mean())
        / comparison["global_linear_rmse"].mean() * 100
    )
    print(f"\n>>> Per-cluster models vs. naive global LINEAR baseline : "
          f"{overall_improvement_vs_linear:+.1f}% RMSE change")
    print(f">>> Per-cluster models vs. strong global XGBOOST baseline: "
          f"{overall_improvement:+.1f}% RMSE change")

    print("\n" + "=" * 70)
    print(" STEP 7 (CREATIVE): INVESTMENT OPPORTUNITY SCORE")
    print("=" * 70)
    investment_df = compute_investment_score(processed, cluster_metrics)
    plot_investment_scores(investment_df)

    print("\n" + "=" * 70)
    print(" STEP 8 (CREATIVE): OVER/UNDERVALUED PROPERTY DETECTOR")
    print("=" * 70)
    flagged_df = flag_over_under_valued(processed, cluster_models, features)
    deals = top_deals(flagged_df, n=10)
    print("\nTop 10 most undervalued properties (potential deals):")
    print(deals.to_string(index=False))

    print("\n" + "=" * 70)
    print(" STEP 9 (CREATIVE): INTERACTIVE VALUATION MAP")
    print("=" * 70)
    build_cluster_valuation_map(flagged_df)

    if run_shap:
        print("\n" + "=" * 70)
        print(" STEP 10 (CREATIVE): SHAP EXPLAINABILITY PER CLUSTER")
        print("=" * 70)
        shap_df = compute_cluster_shap_importance(processed, cluster_models, features)
        top_driver_per_cluster(shap_df)
        plot_cluster_driver_heatmap(shap_df)

    print("\n" + "=" * 70)
    print(" STEP 11: SAVING MODELS & ARTIFACTS")
    print("=" * 70)
    joblib.dump(scaler, f"{models_dir}/scaler.joblib")
    joblib.dump(km, f"{models_dir}/kmeans.joblib")
    joblib.dump(global_model, f"{models_dir}/global_model.joblib")
    joblib.dump(global_linear_model, f"{models_dir}/global_linear_model.joblib")
    joblib.dump(cluster_models, f"{models_dir}/cluster_models.joblib")
    joblib.dump(cluster_names, f"{models_dir}/cluster_names.joblib")
    joblib.dump(features, f"{models_dir}/feature_list.joblib")
    flagged_df.to_csv("reports/scored_properties.csv", index=False)
    comparison.to_csv("reports/global_vs_cluster_comparison.csv", index=False)
    investment_df.to_csv("reports/investment_scores.csv", index=False)
    print(f"[main] Saved all models to '{models_dir}/' and reports to 'reports/'.")

    print("\n" + "=" * 70)
    print(" FINAL SUMMARY")
    print("=" * 70)
    print(f"  Clusters formed             : {n_clusters}")
    print(f"  Naive global LINEAR RMSE     : ${global_linear_metrics['rmse']:,.0f}  (R2={global_linear_metrics['r2']:.3f})")
    print(f"  Strong global XGBOOST RMSE   : ${global_metrics['rmse']:,.0f}  (R2={global_metrics['r2']:.3f})")
    print(f"  Avg. per-cluster model RMSE : ${comparison['cluster_rmse'].mean():,.0f}")
    print(f"  Improvement vs. naive linear : {overall_improvement_vs_linear:+.1f}%")
    print(f"  Improvement vs. strong XGBoost: {overall_improvement:+.1f}%")
    print("=" * 70 + "\n")

    return {
        "processed": processed, "scaler": scaler, "kmeans": km,
        "global_model": global_model, "global_linear_model": global_linear_model,
        "cluster_models": cluster_models,
        "cluster_names": cluster_names, "features": features,
        "comparison": comparison, "investment_df": investment_df,
    }


def demo_prediction(artifacts):
    print("\n" + "=" * 70)
    print(" DEMO: SINGLE-PROPERTY PRICE PREDICTION")
    print("=" * 70)
    sample_property = {
        "longitude": -122.27, "latitude": 37.87, "housing_median_age": 25,
        "total_rooms": 2500, "total_bedrooms": 480, "population": 1100,
        "households": 420, "median_income": 6.5, "ocean_proximity": "NEAR BAY",
    }
    result = predict_price(
        sample_property, artifacts["scaler"], artifacts["kmeans"],
        artifacts["cluster_models"], artifacts["global_model"],
        artifacts["features"], artifacts["cluster_names"], None,
    )
    print(f"Input property: {sample_property}")
    print(f"Assigned micro-market: {result['cluster_name']}")
    print(f"Global model prediction : ${result['global_model_prediction']:,.2f}")
    print(f"Cluster model prediction: ${result['cluster_model_prediction']:,.2f}")
    print(f"Difference vs global    : {result['difference_pct']:+.1f}%")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Real Estate Micro-Market Clustering pipeline")
    parser.add_argument("--clusters", type=int, default=7, help="Number of micro-market clusters (default: 7)")
    parser.add_argument("--data", type=str, default="data/housing.csv", help="Path to housing.csv")
    parser.add_argument("--sample-elbow", action="store_true", help="Run the elbow-method k-scan (slower)")
    parser.add_argument("--no-shap", action="store_true", help="Skip SHAP explainability step (faster)")
    parser.add_argument("--predict", action="store_true", help="Run a demo single-property prediction at the end")
    args = parser.parse_args()

    artifacts = run_pipeline(
        n_clusters=args.clusters,
        data_path=args.data,
        run_elbow_scan=args.sample_elbow,
        run_shap=not args.no_shap,
    )

    if args.predict:
        demo_prediction(artifacts)
