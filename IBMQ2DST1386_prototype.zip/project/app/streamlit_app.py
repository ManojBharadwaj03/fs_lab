"""
streamlit_app.py
-----------------
Creative enhancement #6: Interactive dashboard.

Run with:
    streamlit run app/streamlit_app.py

Requires that `python main.py` has already been run once so that trained
models exist under models/.
"""

import os
import sys
import joblib
import pandas as pd
import streamlit as st

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))
from predict import predict_price

MODELS_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
REPORTS_DIR = os.path.join(os.path.dirname(__file__), "..", "reports")

st.set_page_config(page_title="Micro-Market Real Estate Pricing", layout="wide")


@st.cache_resource
def load_artifacts():
    scaler = joblib.load(f"{MODELS_DIR}/scaler.joblib")
    kmeans = joblib.load(f"{MODELS_DIR}/kmeans.joblib")
    global_model = joblib.load(f"{MODELS_DIR}/global_model.joblib")
    cluster_models = joblib.load(f"{MODELS_DIR}/cluster_models.joblib")
    cluster_names = joblib.load(f"{MODELS_DIR}/cluster_names.joblib")
    features = joblib.load(f"{MODELS_DIR}/feature_list.joblib")
    return scaler, kmeans, global_model, cluster_models, cluster_names, features


st.title("🏘️ Real Estate Pricing & Geographic Micro-Market Clustering")
st.caption(
    "Case Study: houses are priced by their local micro-market, not a single statewide model. "
    "Enter a property's details to compare a global prediction against the correct localized prediction."
)

try:
    scaler, kmeans, global_model, cluster_models, cluster_names, features = load_artifacts()
except FileNotFoundError:
    st.error(
        "No trained models found. Run `python main.py` from the project root first "
        "to train and save the models, then relaunch this dashboard."
    )
    st.stop()

tab1, tab2, tab3 = st.tabs(["🔮 Price Predictor", "📊 Cluster Explorer", "💰 Investment Scores"])

# ------------------------------------------------------------------
# TAB 1 — Price Predictor
# ------------------------------------------------------------------
with tab1:
    st.subheader("Predict a Property's Price")
    col1, col2, col3 = st.columns(3)

    with col1:
        longitude = st.slider("Longitude", -124.5, -114.0, -122.27, 0.01)
        latitude = st.slider("Latitude", 32.5, 42.0, 37.87, 0.01)
        housing_median_age = st.slider("Housing Median Age (yrs)", 1, 55, 25)

    with col2:
        total_rooms = st.number_input("Total Rooms", 1, 40000, 2500)
        total_bedrooms = st.number_input("Total Bedrooms", 1, 8000, 480)
        population = st.number_input("Population", 1, 40000, 1100)

    with col3:
        households = st.number_input("Households", 1, 6000, 420)
        median_income = st.slider("Median Income (tens of thousands USD)", 0.5, 15.0, 6.5, 0.1)
        ocean_proximity = st.selectbox(
            "Ocean Proximity",
            ["NEAR BAY", "<1H OCEAN", "NEAR OCEAN", "INLAND", "ISLAND"],
        )

    if st.button("Predict Price", type="primary"):
        property_dict = {
            "longitude": longitude, "latitude": latitude,
            "housing_median_age": housing_median_age, "total_rooms": total_rooms,
            "total_bedrooms": total_bedrooms, "population": population,
            "households": households, "median_income": median_income,
            "ocean_proximity": ocean_proximity,
        }
        result = predict_price(
            property_dict, scaler, kmeans, cluster_models, global_model,
            features, cluster_names, None,
        )

        st.success(f"Assigned micro-market: **{result['cluster_name']}**")
        m1, m2, m3 = st.columns(3)
        m1.metric("Global Model Prediction", f"${result['global_model_prediction']:,.0f}")
        m2.metric(
            "Micro-Market Model Prediction",
            f"${result['cluster_model_prediction']:,.0f}",
            delta=f"{result['difference_pct']:+.1f}% vs global",
        )
        m3.metric("Cluster ID", result["cluster_id"])
        st.info(
            "The micro-market model is trained only on properties in this cluster, "
            "so it captures local pricing dynamics (e.g. ocean-proximity premiums, "
            "local income effects) that the single global model averages away."
        )

# ------------------------------------------------------------------
# TAB 2 — Cluster Explorer
# ------------------------------------------------------------------
with tab2:
    st.subheader("Discovered Micro-Markets")
    comparison_path = f"{REPORTS_DIR}/global_vs_cluster_comparison.csv"
    if os.path.exists(comparison_path):
        comparison_df = pd.read_csv(comparison_path)
        st.dataframe(comparison_df, use_container_width=True)
        st.bar_chart(comparison_df.set_index("cluster_name")[["global_rmse", "cluster_rmse"]])
    else:
        st.warning("Run `python main.py` first to generate comparison reports.")

    fig_path = os.path.join(REPORTS_DIR, "figures", "cluster_map.png")
    if os.path.exists(fig_path):
        st.image(fig_path, caption="Geographic distribution of discovered micro-markets")

    map_path = os.path.join(REPORTS_DIR, "figures", "valuation_map.html")
    if os.path.exists(map_path):
        st.markdown(f"📍 [Open the interactive valuation map]({map_path}) in your browser.")

# ------------------------------------------------------------------
# TAB 3 — Investment Scores
# ------------------------------------------------------------------
with tab3:
    st.subheader("Micro-Market Investment Opportunity Score")
    inv_path = f"{REPORTS_DIR}/investment_scores.csv"
    if os.path.exists(inv_path):
        inv_df = pd.read_csv(inv_path)
        st.dataframe(inv_df, use_container_width=True)
        st.bar_chart(inv_df.set_index("cluster_name")["investment_score"])
        st.caption(
            "Score blends relative income (demand potential), price-to-income "
            "affordability, and model confidence (R²) into a single 0-100 ranking "
            "of which micro-markets look most attractive."
        )
    else:
        st.warning("Run `python main.py` first to generate the investment score report.")
