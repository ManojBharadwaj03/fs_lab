"""
data_loader.py
--------------
Loads and validates the raw California Housing Prices dataset.
"""

import os
import pandas as pd

REQUIRED_COLUMNS = [
    "longitude", "latitude", "housing_median_age", "total_rooms",
    "total_bedrooms", "population", "households", "median_income",
    "median_house_value", "ocean_proximity",
]


def load_housing_data(path: str = "data/housing.csv") -> pd.DataFrame:
    """
    Load the raw housing CSV and perform basic schema validation.

    Parameters
    ----------
    path : str
        Path to the housing.csv file.

    Returns
    -------
    pd.DataFrame
        Raw, unprocessed housing dataset.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset not found at '{path}'. Place housing.csv in the data/ folder."
        )

    df = pd.read_csv(path)

    missing_cols = set(REQUIRED_COLUMNS) - set(df.columns)
    if missing_cols:
        raise ValueError(f"Dataset is missing required columns: {missing_cols}")

    print(f"[data_loader] Loaded {len(df):,} records with {df.shape[1]} columns from '{path}'.")
    return df


if __name__ == "__main__":
    data = load_housing_data()
    print(data.head())
    print(data.info())
