"""
valuation_score.py
-------------------
Creative enhancement #2 and #3:

1. Investment Opportunity Score (0-100) per cluster — a composite score that
   flags micro-markets with relatively high income (demand potential) but
   relatively low current price (room to appreciate), weighted by how
   confident the cluster's model is (R2).

2. Over/Undervalued Property Detector — flags individual properties whose
   actual price deviates significantly (default: >15%) from what their
   cluster's model predicts, functioning as a simple automated "deal finder"
   / pricing-anomaly detector.
"""

import numpy as np
import pandas as pd


def compute_investment_score(df: pd.DataFrame, cluster_metrics: dict) -> pd.DataFrame:
    """
    Build a per-cluster Investment Opportunity Score (0-100).

    Formula (all components min-max normalized across clusters, 0-1):
        income_score      -> higher median income = more demand potential
        affordability_score -> lower price-to-income ratio = more upside/affordability
        confidence_score   -> higher model R2 = more trustworthy the prediction/score is

        investment_score = 100 * (0.45*income_score + 0.35*affordability_score + 0.20*confidence_score)
    """
    summary = (
        df.groupby(["cluster", "cluster_name"])
        .agg(
            avg_income=("median_income", "mean"),
            avg_price=("median_house_value", "mean"),
            n_properties=("median_house_value", "size"),
        )
        .reset_index()
    )
    summary["price_to_income"] = summary["avg_price"] / (summary["avg_income"] * 10_000)
    summary["r2"] = summary["cluster"].map(lambda c: cluster_metrics.get(c, {}).get("r2", 0.5))

    def minmax(s):
        rng = s.max() - s.min()
        return (s - s.min()) / rng if rng > 0 else pd.Series(0.5, index=s.index)

    income_score = minmax(summary["avg_income"])
    affordability_score = 1 - minmax(summary["price_to_income"])  # lower ratio -> higher score
    confidence_score = minmax(summary["r2"])

    summary["investment_score"] = (
        100 * (0.45 * income_score + 0.35 * affordability_score + 0.20 * confidence_score)
    ).round(1)

    summary = summary.sort_values("investment_score", ascending=False).reset_index(drop=True)
    summary["rank"] = summary.index + 1

    print("[valuation_score] Investment Opportunity Score by cluster (higher = more opportunity):")
    for _, row in summary.iterrows():
        print(f"    #{int(row['rank'])}  {row['cluster_name']:<40} "
              f"score={row['investment_score']:.1f}  "
              f"avg_income=${row['avg_income']*10000:,.0f}  avg_price=${row['avg_price']:,.0f}")

    return summary[[
        "rank", "cluster", "cluster_name", "avg_income", "avg_price",
        "price_to_income", "n_properties", "investment_score",
    ]]


def flag_over_under_valued(df: pd.DataFrame, cluster_models: dict, features: list,
                            threshold_pct: float = 15.0) -> pd.DataFrame:
    """
    For every property, predict its price using its OWN cluster's model,
    compare to the actual price, and flag it as:
        'undervalued'   -> actual price is >threshold_pct% BELOW model prediction
        'overvalued'    -> actual price is >threshold_pct% ABOVE model prediction
        'fair'          -> within threshold_pct%

    This turns the regression models into a practical "deal finder" tool.
    """
    df = df.copy()
    df["predicted_price"] = np.nan

    for cid, model in cluster_models.items():
        mask = df["cluster"] == cid
        if mask.sum() == 0:
            continue
        df.loc[mask, "predicted_price"] = model.predict(df.loc[mask, features])

    df["price_gap_pct"] = (
        (df["median_house_value"] - df["predicted_price"]) / df["predicted_price"] * 100
    )

    def classify(gap):
        if pd.isna(gap):
            return "unscored"
        if gap <= -threshold_pct:
            return "undervalued"
        if gap >= threshold_pct:
            return "overvalued"
        return "fair"

    df["valuation_flag"] = df["price_gap_pct"].apply(classify)

    counts = df["valuation_flag"].value_counts()
    print(f"[valuation_score] Valuation flags (threshold ±{threshold_pct}%):")
    for flag, n in counts.items():
        print(f"    {flag:<12}: {n:,} properties ({n/len(df):.1%})")

    return df


def top_deals(df_flagged: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    """Return the top-n most undervalued properties (best 'deals') for review."""
    undervalued = df_flagged[df_flagged["valuation_flag"] == "undervalued"].copy()
    undervalued = undervalued.sort_values("price_gap_pct").head(n)
    cols = ["longitude", "latitude", "cluster_name", "median_house_value",
            "predicted_price", "price_gap_pct"]
    return undervalued[cols].reset_index(drop=True)


if __name__ == "__main__":
    print("Run via main.py — this module is imported, not run standalone with real data.")
