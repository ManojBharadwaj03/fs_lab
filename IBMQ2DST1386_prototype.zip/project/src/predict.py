"""
predict.py
----------
Single-property prediction API. Given raw property attributes, this module:
  1. Engineers the same derived features used in training
  2. Assigns the property to its nearest micro-market cluster (via the saved
     K-Means model + scaler)
  3. Predicts price using BOTH the global model and the correct cluster model,
     so the value of localized modeling is visible on every single prediction.

Used by both the CLI (main.py --predict) and the Streamlit dashboard.
"""

import numpy as np
import pandas as pd


def _engineer_single(property_dict: dict) -> dict:
    d = dict(property_dict)
    d["rooms_per_household"] = d["total_rooms"] / d["households"]
    d["bedrooms_per_room"] = d["total_bedrooms"] / d["total_rooms"]
    d["population_per_household"] = d["population"] / d["households"]
    return d


def predict_price(property_dict: dict, scaler, kmeans_model, cluster_models: dict,
                   global_model, features: list, cluster_names: dict,
                   ocean_categories: list) -> dict:
    """
    Parameters
    ----------
    property_dict : dict
        Raw property attributes, e.g.:
        {
            "longitude": -122.27, "latitude": 37.87, "housing_median_age": 25,
            "total_rooms": 2500, "total_bedrooms": 480, "population": 1100,
            "households": 420, "median_income": 6.5, "ocean_proximity": "NEAR BAY"
        }
    """
    d = _engineer_single(property_dict)

    # --- cluster assignment ---
    cluster_feat_order = ["latitude", "longitude", "median_income", "population_per_household"]
    cluster_input = np.array([[d[c] for c in cluster_feat_order]])
    cluster_input_scaled = scaler.transform(cluster_input)
    cluster_id = int(kmeans_model.predict(cluster_input_scaled)[0])
    cluster_name = cluster_names.get(cluster_id, f"Cluster {cluster_id}")

    # --- build full feature row (with one-hot ocean_proximity) ---
    row = {f: 0 for f in features}
    for f in features:
        if f in d:
            row[f] = d[f]
    ocean_col = "ocean_" + str(d.get("ocean_proximity", "")).replace("<", "lt").replace(">", "gt").replace("[", "").replace("]", "").replace(" ", "_")
    if ocean_col in row:
        row[ocean_col] = 1

    X = pd.DataFrame([row])[features]

    global_pred = float(global_model.predict(X)[0])

    if cluster_id in cluster_models:
        cluster_pred = float(cluster_models[cluster_id].predict(X)[0])
    else:
        cluster_pred = None

    return {
        "cluster_id": cluster_id,
        "cluster_name": cluster_name,
        "global_model_prediction": round(global_pred, 2),
        "cluster_model_prediction": round(cluster_pred, 2) if cluster_pred is not None else None,
        "difference_pct": (
            round((cluster_pred - global_pred) / global_pred * 100, 2)
            if cluster_pred is not None else None
        ),
    }


if __name__ == "__main__":
    print("Import predict_price() and call it with loaded models — see main.py --predict example.")
