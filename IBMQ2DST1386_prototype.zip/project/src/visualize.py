"""
visualize.py
------------
Static chart generation (matplotlib/seaborn) for the report: elbow method,
geographic cluster scatter, and global-vs-cluster RMSE comparison.
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

FIG_DIR = "reports/figures"


def _ensure_dir():
    os.makedirs(FIG_DIR, exist_ok=True)


def plot_elbow(elbow_df: pd.DataFrame, chosen_k: int, save_path: str = None):
    _ensure_dir()
    save_path = save_path or f"{FIG_DIR}/elbow_plot.png"

    fig, ax1 = plt.subplots(figsize=(7.5, 4.8))
    color1 = "#2E5266"
    ax1.plot(elbow_df["k"], elbow_df["inertia"], marker="o", color=color1, linewidth=2, label="Inertia (WCSS)")
    ax1.set_xlabel("Number of Clusters (k)")
    ax1.set_ylabel("Inertia (WCSS)", color=color1)
    ax1.tick_params(axis="y", labelcolor=color1)
    ax1.axvline(x=chosen_k, color="#C1666B", linestyle="--", linewidth=1.5, alpha=0.8)

    ax2 = ax1.twinx()
    color2 = "#C1666B"
    ax2.plot(elbow_df["k"], elbow_df["silhouette"], marker="s", color=color2,
              linewidth=2, linestyle="--", label="Silhouette Score")
    ax2.set_ylabel("Silhouette Score", color=color2)
    ax2.tick_params(axis="y", labelcolor=color2)

    plt.title(f"Elbow Method & Silhouette Score  (chosen k = {chosen_k})", fontsize=12, fontweight="bold")
    fig.tight_layout()
    plt.savefig(save_path, dpi=170)
    plt.close()
    print(f"[visualize] Saved elbow plot to {save_path}")


def plot_cluster_map(df: pd.DataFrame, save_path: str = None):
    _ensure_dir()
    save_path = save_path or f"{FIG_DIR}/cluster_map.png"

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    clusters = sorted(df["cluster"].unique())
    cmap = plt.get_cmap("tab10")

    for i, cid in enumerate(clusters):
        group = df[df["cluster"] == cid]
        cname = group["cluster_name"].iloc[0]
        ax.scatter(group["longitude"], group["latitude"], s=8, alpha=0.55,
                   color=cmap(i % 10), label=cname, edgecolors="none")

    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Discovered Geographic Micro-Market Clusters", fontsize=12, fontweight="bold")
    ax.legend(loc="upper left", fontsize=7, framealpha=0.9)
    ax.grid(True, linestyle="--", alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=170)
    plt.close()
    print(f"[visualize] Saved cluster map to {save_path}")


def plot_rmse_comparison(comparison_df: pd.DataFrame, save_path: str = None):
    _ensure_dir()
    save_path = save_path or f"{FIG_DIR}/rmse_comparison.png"

    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(comparison_df))
    has_linear = "global_linear_rmse" in comparison_df.columns
    width = 0.26 if has_linear else 0.36

    if has_linear:
        ax.bar(x - width, comparison_df["global_linear_rmse"], width,
               label="Naive Global Linear Model", color="#B0A990")
        ax.bar(x, comparison_df["global_rmse"], width,
               label="Strong Global XGBoost Model", color="#8E7C93")
        ax.bar(x + width, comparison_df["cluster_rmse"], width,
               label="Per-Cluster Model", color="#2E5266")
    else:
        ax.bar(x - width / 2, comparison_df["global_rmse"], width, label="Global Model", color="#B0A990")
        ax.bar(x + width / 2, comparison_df["cluster_rmse"], width, label="Per-Cluster Model", color="#2E5266")

    ax.set_xticks(x)
    ax.set_xticklabels(comparison_df["cluster_name"], rotation=30, ha="right", fontsize=8)
    ax.set_ylabel("RMSE (USD)")
    ax.set_title("Prediction Error: Naive Global vs. Strong Global vs. Per-Cluster Models",
                 fontsize=12, fontweight="bold")
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=170)
    plt.close()
    print(f"[visualize] Saved RMSE comparison chart to {save_path}")


def plot_investment_scores(investment_df: pd.DataFrame, save_path: str = None):
    _ensure_dir()
    save_path = save_path or f"{FIG_DIR}/investment_scores.png"

    fig, ax = plt.subplots(figsize=(8, 5))
    sorted_df = investment_df.sort_values("investment_score")
    colors = plt.get_cmap("RdYlGn")(sorted_df["investment_score"] / 100)

    ax.barh(sorted_df["cluster_name"], sorted_df["investment_score"], color=colors)
    ax.set_xlabel("Investment Opportunity Score (0-100)")
    ax.set_title("Micro-Market Investment Opportunity Score", fontsize=12, fontweight="bold")
    ax.grid(axis="x", linestyle="--", alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=170)
    plt.close()
    print(f"[visualize] Saved investment score chart to {save_path}")
