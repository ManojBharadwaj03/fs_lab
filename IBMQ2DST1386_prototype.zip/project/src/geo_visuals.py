"""
geo_visuals.py
--------------
Creative enhancement #5: an interactive HTML map (Folium / Leaflet) plotting
every property, colored by micro-market cluster, with a popup showing the
actual price, the model's predicted price, and whether it's flagged as
over/undervalued. Open the resulting HTML file in any browser — no server needed.
"""

import folium
import pandas as pd

CLUSTER_COLORS = [
    "#2E5266", "#6E8898", "#C1666B", "#D4B483",
    "#4C7273", "#8E7C93", "#B0A990", "#6B8E23",
    "#8B4513", "#20639B",
]

FLAG_ICON_COLOR = {
    "undervalued": "green",
    "overvalued": "red",
    "fair": "lightgray",
    "unscored": "gray",
}


def build_cluster_valuation_map(df_flagged: pd.DataFrame, sample_size: int = 1500,
                                 save_path: str = "reports/figures/valuation_map.html"):
    """
    Build an interactive Folium map:
      - Each property is a small colored circle marker (color = cluster)
      - Popup shows cluster name, actual price, predicted price, valuation flag
      - A layer toggle lets you show only undervalued ('deal') properties

    A random sample is used (default 1500) to keep the HTML file light and fast
    to render in a browser.
    """
    sample = df_flagged.sample(min(sample_size, len(df_flagged)), random_state=42)

    center_lat, center_lon = sample["latitude"].mean(), sample["longitude"].mean()
    m = folium.Map(location=[center_lat, center_lon], zoom_start=6, tiles="cartodbpositron")

    all_layer = folium.FeatureGroup(name="All sampled properties", show=True)
    deals_layer = folium.FeatureGroup(name="⭐ Undervalued deals only", show=False)

    clusters = sorted(sample["cluster"].unique())
    color_map = {cid: CLUSTER_COLORS[i % len(CLUSTER_COLORS)] for i, cid in enumerate(clusters)}

    for _, row in sample.iterrows():
        popup_html = (
            f"<b>{row['cluster_name']}</b><br>"
            f"Actual price: ${row['median_house_value']:,.0f}<br>"
            f"Model prediction: ${row['predicted_price']:,.0f}<br>"
            f"Gap: {row['price_gap_pct']:+.1f}%<br>"
            f"Flag: <b>{row['valuation_flag'].upper()}</b>"
        )
        marker = folium.CircleMarker(
            location=[row["latitude"], row["longitude"]],
            radius=4,
            color=color_map[row["cluster"]],
            fill=True,
            fill_color=color_map[row["cluster"]],
            fill_opacity=0.75,
            weight=1,
            popup=folium.Popup(popup_html, max_width=250),
        )
        marker.add_to(all_layer)

        if row["valuation_flag"] == "undervalued":
            deal_marker = folium.CircleMarker(
                location=[row["latitude"], row["longitude"]],
                radius=5,
                color="green",
                fill=True,
                fill_color="green",
                fill_opacity=0.85,
                weight=1,
                popup=folium.Popup(popup_html, max_width=250),
            )
            deal_marker.add_to(deals_layer)

    all_layer.add_to(m)
    deals_layer.add_to(m)
    folium.LayerControl(collapsed=False).add_to(m)

    m.save(save_path)
    print(f"[geo_visuals] Interactive valuation map saved to {save_path} "
          f"({len(sample):,} properties plotted)")
    return m
