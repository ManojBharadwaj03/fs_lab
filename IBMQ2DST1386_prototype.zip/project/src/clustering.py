"""
clustering.py
--------------
Discovers geographic micro-markets using K-Means, selects the optimal number
of clusters via the elbow method + silhouette score, and auto-generates
human-readable cluster names from each cluster's own statistics (creative
enhancement — no manual labeling required).
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Known reference points used only to generate a human-friendly geographic
# label for each cluster centroid (nearest-neighbor lookup, not used in modeling).
REFERENCE_POINTS = {
    "Bay Area": (37.77, -122.42),
    "LA Metro": (34.05, -118.24),
    "San Diego": (32.72, -117.16),
    "Sacramento": (38.58, -121.49),
    "Central Valley": (36.75, -119.77),
    "Inland Empire / Desert": (33.95, -116.50),
    "Northern California": (40.58, -122.39),
}


def find_optimal_k(scaled_features: np.ndarray, k_range=range(2, 13)) -> pd.DataFrame:
    """
    Run K-Means across a range of k values and record inertia + silhouette score
    so the optimal number of micro-markets can be chosen (elbow method).
    """
    results = []
    for k in k_range:
        km = KMeans(n_clusters=k, init="k-means++", n_init=10, random_state=42)
        labels = km.fit_predict(scaled_features)
        sil = silhouette_score(scaled_features, labels, sample_size=5000, random_state=42)
        results.append({"k": k, "inertia": km.inertia_, "silhouette": sil})
        print(f"[clustering] k={k:2d}  inertia={km.inertia_:,.0f}  silhouette={sil:.3f}")

    return pd.DataFrame(results)


def fit_kmeans(scaled_features: np.ndarray, n_clusters: int = 7, random_state: int = 42) -> KMeans:
    """Fit the final K-Means model with the chosen number of clusters."""
    km = KMeans(n_clusters=n_clusters, init="k-means++", n_init=10, random_state=random_state)
    km.fit(scaled_features)
    return km


def _nearest_region_name(lat: float, lon: float) -> str:
    best_name, best_dist = None, float("inf")
    for name, (rlat, rlon) in REFERENCE_POINTS.items():
        dist = (lat - rlat) ** 2 + (lon - rlon) ** 2
        if dist < best_dist:
            best_dist, best_name = dist, name
    return best_name


def auto_name_clusters(df: pd.DataFrame, cluster_col: str = "cluster") -> dict:
    """
    Automatically generate a human-readable name for each cluster based on:
      - nearest reference region (geography)
      - income tier (relative to statewide median)
      - density tier (population_per_household, relative to statewide median)

    This makes the pipeline fully data-driven — clusters are named the same way
    no matter what data or how many clusters are used, with no manual labeling step.

    Returns
    -------
    dict[int, str] mapping cluster id -> generated name
    """
    income_median = df["median_income"].median()
    density_median = df["population_per_household"].median()

    names = {}
    for cid, group in df.groupby(cluster_col):
        lat, lon = group["latitude"].mean(), group["longitude"].mean()
        region = _nearest_region_name(lat, lon)

        income_tier = "High-Income" if group["median_income"].mean() > income_median * 1.15 else (
            "Low-Income" if group["median_income"].mean() < income_median * 0.85 else "Mid-Income"
        )
        density_tier = "Urban" if group["population_per_household"].mean() > density_median * 1.1 else (
            "Rural" if group["population_per_household"].mean() < density_median * 0.9 else "Suburban"
        )

        names[cid] = f"{region} — {income_tier} {density_tier}"

    print("[clustering] Auto-generated cluster names:")
    for cid, name in sorted(names.items()):
        print(f"    Cluster {cid}: {name}")

    return names


def assign_clusters(df: pd.DataFrame, kmeans_model: KMeans, scaled_features: np.ndarray) -> pd.DataFrame:
    """Attach cluster labels + auto-generated names to the dataframe."""
    df = df.copy()
    df["cluster"] = kmeans_model.predict(scaled_features)
    cluster_names = auto_name_clusters(df)
    df["cluster_name"] = df["cluster"].map(cluster_names)
    return df, cluster_names


if __name__ == "__main__":
    import sys
    sys.path.append(".")
    from data_loader import load_housing_data
    from preprocessing import build_feature_matrix

    raw = load_housing_data("../data/housing.csv")
    processed, scaler, scaled = build_feature_matrix(raw)

    elbow_df = find_optimal_k(scaled)
    km = fit_kmeans(scaled, n_clusters=7)
    processed, names = assign_clusters(processed, km, scaled)
    print(processed[["latitude", "longitude", "cluster", "cluster_name"]].head(10))
