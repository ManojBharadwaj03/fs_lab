"""
preprocessing.py
-----------------
Cleaning and feature engineering for the California Housing dataset.

Steps:
    1. Impute missing total_bedrooms using a geographic-grid-local median
       (rather than a single global median) so local density patterns are preserved.
    2. Flag price-capped records (median_house_value == 500001, a census artifact).
    3. Engineer density/composition ratio features.
    4. One-hot encode the ocean_proximity categorical feature.
    5. Scale continuous features for use in K-Means (distance-based).
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

CAPPED_VALUE = 500001


def _grid_cell(df: pd.DataFrame, cell_size: float = 1.0) -> pd.Series:
    """Assign a coarse geographic grid-cell id used only for local imputation."""
    lon_bin = (df["longitude"] / cell_size).round().astype(int)
    lat_bin = (df["latitude"] / cell_size).round().astype(int)
    return lon_bin.astype(str) + "_" + lat_bin.astype(str)


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Handle missing values and flag capped price records."""
    df = df.copy()

    # --- Local (grid-cell) median imputation for total_bedrooms ---
    df["_grid_cell"] = _grid_cell(df)
    grid_median = df.groupby("_grid_cell")["total_bedrooms"].transform("median")
    global_median = df["total_bedrooms"].median()
    df["total_bedrooms"] = df["total_bedrooms"].fillna(grid_median).fillna(global_median)
    df.drop(columns="_grid_cell", inplace=True)

    # --- Flag capped price records (census reporting artifact at $500,001) ---
    df["is_price_capped"] = (df["median_house_value"] >= CAPPED_VALUE).astype(int)

    n_missing_fixed = df["total_bedrooms"].isna().sum()
    n_capped = df["is_price_capped"].sum()
    print(f"[preprocessing] Missing total_bedrooms remaining after imputation: {n_missing_fixed}")
    print(f"[preprocessing] Price-capped records flagged: {n_capped} ({n_capped / len(df):.1%})")

    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create derived ratio features that capture density & household composition."""
    df = df.copy()
    df["rooms_per_household"] = df["total_rooms"] / df["households"]
    df["bedrooms_per_room"] = df["total_bedrooms"] / df["total_rooms"]
    df["population_per_household"] = df["population"] / df["households"]

    # Guard against divide-by-zero / inf edge cases
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    for col in ["rooms_per_household", "bedrooms_per_room", "population_per_household"]:
        df[col] = df[col].fillna(df[col].median())

    print("[preprocessing] Engineered features: rooms_per_household, "
          "bedrooms_per_room, population_per_household")
    return df


def encode_categorical(df: pd.DataFrame) -> pd.DataFrame:
    """One-hot encode ocean_proximity. Column names are sanitized (no <, [, ])
    so they are safe for all downstream estimators, including XGBoost."""
    df = df.copy()
    dummies = pd.get_dummies(df["ocean_proximity"], prefix="ocean")
    dummies.columns = [
        c.replace("<", "lt").replace(">", "gt").replace("[", "").replace("]", "").replace(" ", "_")
        for c in dummies.columns
    ]
    df = pd.concat([df, dummies], axis=1)
    return df


CLUSTER_FEATURES = ["latitude", "longitude", "median_income", "population_per_household"]

REGRESSION_FEATURES_BASE = [
    "longitude", "latitude", "housing_median_age", "total_rooms", "total_bedrooms",
    "population", "households", "median_income",
    "rooms_per_household", "bedrooms_per_room", "population_per_household",
]


def build_feature_matrix(df: pd.DataFrame):
    """
    Full preprocessing pipeline: clean -> engineer -> encode.

    Returns
    -------
    df_processed : pd.DataFrame
        Fully processed dataframe (adds engineered + encoded columns).
    scaler : StandardScaler
        Fitted scaler on the clustering feature set (needed to transform new data).
    scaled_cluster_features : np.ndarray
        Scaled array used as direct input to K-Means.
    """
    df = clean_data(df)
    df = engineer_features(df)
    df = encode_categorical(df)

    # Clip extreme outliers in the clustering feature set only (not the regression
    # features) so a handful of pathological records (e.g. households=1 with high
    # population) don't get isolated into their own degenerate single-point clusters.
    cluster_input = df[CLUSTER_FEATURES].copy()
    for col in ["median_income", "population_per_household"]:
        lower, upper = cluster_input[col].quantile([0.01, 0.99])
        cluster_input[col] = cluster_input[col].clip(lower, upper)

    scaler = StandardScaler()
    scaled_cluster_features = scaler.fit_transform(cluster_input)

    return df, scaler, scaled_cluster_features


if __name__ == "__main__":
    from data_loader import load_housing_data

    raw = load_housing_data("../data/housing.csv")
    processed, scaler, scaled = build_feature_matrix(raw)
    print(processed.head())
    print(f"Processed shape: {processed.shape}")
