"""
modeling.py
-----------
Trains and evaluates regression models both globally (single statewide model)
and per-cluster (micro-market-specific models), then compares them fairly.

IMPORTANT DESIGN NOTE (avoiding data leakage):
A single train/test split is computed ONCE on the full dataset. The global
model is trained on the global training rows and evaluated on the global test
rows. Each cluster's model is trained ONLY on that cluster's subset of the
SAME global training rows, and evaluated ONLY on that cluster's subset of the
SAME global test rows. This guarantees every comparison is apples-to-apples:
no record used to train the global model is ever used to test a cluster
model or vice versa, and both approaches are scored on identical held-out data.

Creative enhancement: for each cluster, three candidate algorithms
(Linear Regression, Random Forest, XGBoost) are trained and the best one
(by test RMSE) is automatically selected as that cluster's "champion" model —
a simple champion/challenger framework rather than a single fixed algorithm.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from xgboost import XGBRegressor

from preprocessing import REGRESSION_FEATURES_BASE

TARGET = "median_house_value"
MIN_CLUSTER_TEST_SIZE = 20  # a cluster's test slice must have at least this many rows to be scored


def _feature_columns(df: pd.DataFrame) -> list:
    ocean_cols = [c for c in df.columns if c.startswith("ocean_") and c != "ocean_proximity"]
    return REGRESSION_FEATURES_BASE + ocean_cols


CANDIDATE_MODELS = {
    "linear_regression": lambda: LinearRegression(),
    "random_forest": lambda: RandomForestRegressor(
        n_estimators=200, max_depth=14, min_samples_leaf=3, random_state=42, n_jobs=-1
    ),
    "xgboost": lambda: XGBRegressor(
        n_estimators=300, max_depth=6, learning_rate=0.08,
        subsample=0.85, colsample_bytree=0.85, random_state=42, n_jobs=-1
    ),
}


def _evaluate(model, X_test, y_test) -> dict:
    preds = model.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(y_test, preds)))
    mae = float(mean_absolute_error(y_test, preds))
    r2 = float(r2_score(y_test, preds))
    return {"rmse": rmse, "mae": mae, "r2": r2}


def make_global_split(df: pd.DataFrame, test_size=0.2, random_state=42):
    """
    Create ONE train/test split for the whole dataset. All downstream models
    (global and per-cluster) are trained/evaluated against this same split,
    which is what makes the final comparison leakage-free and fair.
    """
    train_idx, test_idx = train_test_split(
        df.index, test_size=test_size, random_state=random_state
    )
    return train_idx, test_idx


def train_global_baseline(df: pd.DataFrame, train_idx, test_idx, algorithm="xgboost"):
    """Train a single global model on the full training split (no clustering)."""
    features = _feature_columns(df)
    X_train, y_train = df.loc[train_idx, features], df.loc[train_idx, TARGET]
    X_test, y_test = df.loc[test_idx, features], df.loc[test_idx, TARGET]

    model = CANDIDATE_MODELS[algorithm]()
    model.fit(X_train, y_train)
    metrics = _evaluate(model, X_test, y_test)

    print(f"[modeling] GLOBAL baseline ({algorithm}): "
          f"RMSE={metrics['rmse']:,.0f}  MAE={metrics['mae']:,.0f}  R2={metrics['r2']:.3f}  "
          f"(train n={len(X_train):,}, test n={len(X_test):,})")

    return model, metrics, features


def train_cluster_models(df: pd.DataFrame, train_idx, test_idx, min_cluster_train_size=50):
    """
    Train champion/challenger models within each cluster, using ONLY the rows
    that fall in the global training split, and evaluate ONLY on the rows that
    fall in the global test split. This keeps every cluster model's evaluation
    perfectly comparable to the global model's evaluation on the same records.

    Returns
    -------
    cluster_models : dict[int, sklearn-like estimator]   best model per cluster
    cluster_metrics : dict[int, dict]                     metrics of the champion model per cluster
    all_candidate_metrics : dict[int, dict[str, dict]]     metrics of every candidate, for transparency
    features : list[str]
    """
    features = _feature_columns(df)
    train_df = df.loc[train_idx]
    test_df = df.loc[test_idx]

    cluster_models, cluster_metrics, all_candidate_metrics = {}, {}, {}

    for cid in sorted(df["cluster"].unique()):
        cluster_train = train_df[train_df["cluster"] == cid]
        cluster_test = test_df[test_df["cluster"] == cid]

        if len(cluster_train) < min_cluster_train_size or len(cluster_test) < MIN_CLUSTER_TEST_SIZE:
            print(f"[modeling] Skipping cluster {cid} — insufficient data "
                  f"(train={len(cluster_train)}, test={len(cluster_test)}).")
            continue

        X_train, y_train = cluster_train[features], cluster_train[TARGET]
        X_test, y_test = cluster_test[features], cluster_test[TARGET]

        best_name, best_model, best_metrics = None, None, None
        candidate_results = {}

        for name, factory in CANDIDATE_MODELS.items():
            model = factory()
            model.fit(X_train, y_train)
            metrics = _evaluate(model, X_test, y_test)
            candidate_results[name] = metrics

            if best_metrics is None or metrics["rmse"] < best_metrics["rmse"]:
                best_name, best_model, best_metrics = name, model, metrics

        cluster_models[cid] = best_model
        cluster_metrics[cid] = {**best_metrics, "algorithm": best_name,
                                 "n_train": len(cluster_train), "n_test": len(cluster_test)}
        all_candidate_metrics[cid] = candidate_results

        cname = cluster_train["cluster_name"].iloc[0]
        print(f"[modeling] Cluster {cid} ({cname}) — champion: {best_name}  "
              f"RMSE={best_metrics['rmse']:,.0f}  R2={best_metrics['r2']:.3f}  "
              f"(train n={len(cluster_train):,}, test n={len(cluster_test):,})")

    return cluster_models, cluster_metrics, all_candidate_metrics, features


def compare_global_vs_cluster(df: pd.DataFrame, global_model, cluster_models: dict,
                               features: list, test_idx, global_linear_model=None) -> pd.DataFrame:
    """
    Apples-to-apples comparison: for EACH cluster's slice of the SAME global
    test set, compute RMSE under (a) a naive global Linear Regression baseline
    (the classic "one-size-fits-all" model this case study argues against),
    (b) a strong global XGBoost model, and (c) that cluster's own champion
    model. All three are evaluated on identical held-out rows.
    """
    test_df = df.loc[test_idx]
    rows = []
    for cid in sorted(df["cluster"].unique()):
        if cid not in cluster_models:
            continue
        cluster_test = test_df[test_df["cluster"] == cid]
        if len(cluster_test) < MIN_CLUSTER_TEST_SIZE:
            continue

        X_test = cluster_test[features]
        y_test = cluster_test[TARGET]

        global_preds = global_model.predict(X_test)
        cluster_preds = cluster_models[cid].predict(X_test)

        row = {
            "cluster": cid,
            "cluster_name": cluster_test["cluster_name"].iloc[0],
            "n_test": len(X_test),
            "global_rmse": float(np.sqrt(mean_squared_error(y_test, global_preds))),
            "cluster_rmse": float(np.sqrt(mean_squared_error(y_test, cluster_preds))),
        }

        if global_linear_model is not None:
            linear_preds = global_linear_model.predict(X_test)
            row["global_linear_rmse"] = float(np.sqrt(mean_squared_error(y_test, linear_preds)))

        rows.append(row)

    comparison = pd.DataFrame(rows)
    comparison["improvement_vs_xgb_global_pct"] = (
        (comparison["global_rmse"] - comparison["cluster_rmse"]) / comparison["global_rmse"] * 100
    )
    if "global_linear_rmse" in comparison.columns:
        comparison["improvement_vs_linear_global_pct"] = (
            (comparison["global_linear_rmse"] - comparison["cluster_rmse"])
            / comparison["global_linear_rmse"] * 100
        )
    return comparison


if __name__ == "__main__":
    import sys
    sys.path.append(".")
    from data_loader import load_housing_data
    from preprocessing import build_feature_matrix
    from clustering import fit_kmeans, assign_clusters

    raw = load_housing_data("../data/housing.csv")
    processed, scaler, scaled = build_feature_matrix(raw)
    km = fit_kmeans(scaled, n_clusters=7)
    processed, names = assign_clusters(processed, km, scaled)

    train_idx, test_idx = make_global_split(processed)
    global_model, global_metrics, features = train_global_baseline(processed, train_idx, test_idx)
    cluster_models, cluster_metrics, candidates, _ = train_cluster_models(processed, train_idx, test_idx)
    comparison = compare_global_vs_cluster(processed, global_model, cluster_models, features, test_idx)
    print(comparison)
